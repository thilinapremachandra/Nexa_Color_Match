Semantic Segmentation Demo
==========================

This directory contains a notebook for demonstrating the benchmark
semantic segmentation network from the the ADE20K MIT Scene Parsing
Benchchmark.

It can be run on Colab at
[this URL](https://colab.research.google.com/github/CSAILVision/semantic-segmentation-pytorch/blob/master/notebooks/DemoSegmenter.ipynb)
or on a local Jupyter notebook.

If running locally, run the script `setup_notebooks.sh` to start.
